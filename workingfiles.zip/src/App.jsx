import Content from "./components/Content";
import NavBar from "./components/Navbar";
function App() {
  return (
    <>
      <div>
        <NavBar />
        <Content />
      </div>
    </>
  );
}
export default App;
